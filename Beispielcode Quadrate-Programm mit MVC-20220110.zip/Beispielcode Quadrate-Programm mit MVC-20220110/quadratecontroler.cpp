#define _USE_MATH_DEFINES
#include "quadratecontroler.h"

#include<cstdlib>
#include<ctime>
#include<cmath>

#include<QEvent>
#include<QMouseEvent>
#include<QKeyEvent>

#include"quadratemodel.h"
#include"quadratewidget.h"

QuadrateControler::QuadrateControler(QuadrateModel& model, QuadrateWidget& ansicht, QObject* parent)
    : QObject(parent)
    , m_model (model)
    , m_view(ansicht)
{
	ansicht.installEventFilter(this);
}

void QuadrateControler::mousePressEvent(QMouseEvent* event)
{
	const double breite = m_view.width();
	const double hoehe = m_view.height();

	if (event->button() == Qt::LeftButton)
	{
		m_model.quadratHinzufuegen(event->x()/breite, event->y()/hoehe);
	}
}

void QuadrateControler::keyPressEvent(QKeyEvent* event)
{
	switch (event->key()) 
	{
	case Qt::Key_Delete:
		m_model.quadratEntfernen();
		break;
   // ggf. weitere Tasten 
	default:
		break;
	}
}

// Eventfilter um die Ereignise von der Ansicht (QuadrateWidget) abzufangen : 
// MVC: die Ereignise werden von der Steuerung verarbeitet
bool QuadrateControler::eventFilter(QObject* /*watched*/, QEvent* event)
{
	switch (event->type()) // Bestimmen des Ereignistyps 
	{
		// relevante Ereignistypen behandeln:
		// cast auf speziellen Typ durchfuehren und die speziellen Event-Methoden aufrufen
	case QEvent::MouseButtonPress:
		mousePressEvent(dynamic_cast<QMouseEvent*>(event));
		break;
	case QEvent::KeyPress:
		keyPressEvent(dynamic_cast<QKeyEvent*>(event));
		break;
	default:
		return false;
	}
	return event->isAccepted();
}



