#ifndef QUADRATEWIDGET_H
#define QUADRATEWIDGET_H

#include<vector>
#include<limits>

#include<QWidget>

class QuadrateModel;

class QuadrateWidget : public QWidget
{
	Q_OBJECT

	// Fuer die Zeichenfunktion wird das Modell benoetigt (Zugriff auf die Quadrate) 
   // -> Speicherung einer Referenz auf das Modell
	QuadrateModel &m_model;

public:
	// Die Ansicht kennt in MVC das Modell, also wird es per Referenz uebergeben
	QuadrateWidget(QuadrateModel &model, QWidget* parent = nullptr);

protected:
	// von den Events verbleibt nur das paintEvent, 
	// alle anderen werden durch den EventFilter direkt von der Steuerung (QuadrateContoler) behandelt
	void paintEvent(QPaintEvent* event) override;
};

#endif // QUADRATEWIDGET_H
