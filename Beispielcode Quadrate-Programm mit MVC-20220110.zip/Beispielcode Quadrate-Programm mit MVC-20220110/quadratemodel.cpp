#define _USE_MATH_DEFINES
#include "quadratemodel.h"

#include<algorithm>
#include<cstdlib>
#include<ctime>
#include<cmath>


QuadrateModel::QuadrateModel(QObject* parent)
    : QObject(parent)
{
	// Zufallsinitialisierung 
	std::srand(std::time(0));

	for(int i = 0; i < m_numStartQuadrate; ++i)
	{
		double x = static_cast<double>(std::rand())/RAND_MAX;
		double y = static_cast<double>(std::rand())/RAND_MAX;

		quadratHinzufuegen(x, y);
	}
}

void QuadrateModel::quadratHinzufuegen(double x, double y)
{
	// Farbe erzeugen
	uint8_t rot = std::rand() % 255;
	uint8_t gruen = std::rand() % 255;
	uint8_t blau = std::rand() % 255;

	// Quadrat einfuegen
	m_quadrate.emplace_back(x,y, qRgb(rot, gruen, blau));
	emit(quadrateGeaendert()); // die Daten wurden ge�ndert (Qudarat hinzugef�gt), das wird jetzt bekannt gegeben
}

void QuadrateModel::quadratEntfernen()
{
	// Quadrat entfernen
	if ( !m_quadrate.empty() )
	   m_quadrate.pop_back();
	emit(quadrateGeaendert()); // die Daten wurden ge�ndert (Qudarat hinzugef�gt), das wird jetzt bekannt gegeben
}




