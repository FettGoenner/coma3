#define _USE_MATH_DEFINES
#include "quadratewidget.h"
#include "quadratemodel.h"

#include<cmath>

#include<QPaintEvent>
#include<QPainter>
#include<QRectF>
#include<QMouseEvent>

#include<QDebug>

QuadrateWidget::QuadrateWidget(QuadrateModel &model, QWidget* parent)
: QWidget(parent)
, m_model(model)
{
	setFocusPolicy(Qt::StrongFocus);

	// wenn sich beim Modell was geaendert hat, soll neu gezeichnet werden 
	// (die Ansicht beobachtet das Model)
	connect(&m_model, &QuadrateModel::quadrateGeaendert, this, QOverload<>::of(&QuadrateWidget::update));
}


// Zeichenfunktion
void QuadrateWidget::paintEvent(QPaintEvent* /*event*/)
{
	const double breite = width();
	const double hoehe  = height();

	QPainter p(this);

	for(const QuadrateModel::Quadrat& quad : m_model.getQuadrate()) 
	{
		p.setBrush(QBrush(quad.farbe));
		p.drawRect(static_cast<int>(quad.x*breite)-10
		         , static_cast<int>(quad.y*hoehe )-10
		         , 20
		         , 20);
	}
}




