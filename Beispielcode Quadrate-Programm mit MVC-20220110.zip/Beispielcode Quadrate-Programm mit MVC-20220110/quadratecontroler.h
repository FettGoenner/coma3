#ifndef QUADRATECONTROLER_H
#define QUADRATECONTROLER_H

#include <QObject>

class QMouseEvent;
class QKeyEvent;

class QuadrateModel;
class QuadrateWidget;

class QuadrateControler : public QObject
{
	Q_OBJECT

	// MVC: Die Steuerung kennt sowohl das Modell als auch die Ansicht
	// Referenzen auf die beiden Objekte (keine Kopie oder eigene Objekte!)
	QuadrateModel& m_model;
	QuadrateWidget& m_view;

public:
	// damit wir die Modell- und Ansicht-Referenz sinnvoll instanzieren koennen, 
	// muessen wir die Objekte auch uebergeben
	// der parent dient wie immer in Qt der automatischen Speicherbereinigung durch Qt
	explicit QuadrateControler(QuadrateModel& model, QuadrateWidget& view, QObject *parent = nullptr);

	void mousePressEvent(QMouseEvent* event);
	void keyPressEvent(QKeyEvent* event);

	// Eventfilter um die Ereignise von der Ansicht (QuadrateWidget) abzufangen
	bool eventFilter(QObject* watched, QEvent* event) override;
};

#endif // QUADRATECONTROLER_H
