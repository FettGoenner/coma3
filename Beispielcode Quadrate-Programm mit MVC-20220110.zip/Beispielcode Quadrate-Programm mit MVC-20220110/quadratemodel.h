#ifndef QUADRATEMODEL_H
#define QUADRATEMODEL_H

#include<QObject>
#include<QColor>

class QuadrateModel : public QObject
{
	Q_OBJECT

public:
	
	QuadrateModel(QObject* parent);


	// Struktur/Klasse für die Daten eines Quadrats
	// hier public, da auf diese Datenstruktur von der Ansicht aus zugegriffen wird
	struct Quadrat
	{
		Quadrat(double x, double y, const QColor& farbe)
		: x(x)
		, y(y)
		, farbe(farbe)
		{}

		double x;
		double y;

		QColor farbe;
	};

	// Quadrate-Vektor als konstante (unveraenderliche) Referenz rausgeben 
	// (wird von der Ansicht zum Zeichnen benutzt)
	const std::vector<Quadrat>& getQuadrate() const { return m_quadrate; }

	void quadratHinzufuegen(double x, double y);
	void quadratEntfernen();

private:
	// Die Struktur Quadrat ist zwar public, die Daten bleiben aber privat (Klassenkapslung) 
	// -> Es kann kontrolliert werden, was mit den Daten passiert und wer darauf zugreifen darf
	std::vector<Quadrat> m_quadrate = std::vector<Quadrat>();

	// Hilfswert fuer die Zufallsinitialisierung
	static const std::size_t m_numStartQuadrate = 30;

signals:
	void quadrateGeaendert(); // Dieses Signal wird immer dann gesendet (durch einen Funktionsaufruf in der Klasse), wenn sich die Daten geaendert haben
	// dies kann sicher bestimmt werden, da die Daten privat, also gekapselt sind. Ein schreibender Zugriff erfolgt also ausschließlich durch die Methoden.

};

#endif // QUADRATEMODEL_H
