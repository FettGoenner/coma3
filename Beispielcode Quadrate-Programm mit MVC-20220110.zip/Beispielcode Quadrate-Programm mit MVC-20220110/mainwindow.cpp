#include "mainwindow.h"

#include<QWidget>
#include<QVBoxLayout>
#include<QPushButton>

#include<QDialog>

#include "quadratemodel.h"
#include "quadratewidget.h"
#include "quadratecontroler.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
	resize(500, 500);

	QuadrateModel *quadModel = new QuadrateModel(this);
	QuadrateWidget  *quadAnsicht = new QuadrateWidget(*quadModel);
	setCentralWidget(quadAnsicht);

	new QuadrateControler(*quadModel, *quadAnsicht, this);
}

MainWindow::~MainWindow()
{
}
